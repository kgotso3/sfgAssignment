#import cv2
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import uuid
from datetime import datetime, timedelta
import sqlite3
from flask import jsonify
#staffNumber = '12345'
def generate_payment_date():
    current_date = datetime.now()
    payment_date = current_date + timedelta(days=30)
    return payment_date

def generate_ticket_number():
    ticket_number = uuid.uuid4().hex[:8]  
    return ticket_number

def process_car_image(image_path):
    registration_number = "ABC123"  # Dummy registration number
    return registration_number

def generate_pdf_ticket(registration_number, parking_location, ticket_number, payment_date, car_picture1, car_picture2, officerNumber, finePrice):
    c = canvas.Canvas(f"tickets/parking_ticket_{ticket_number}.pdf", pagesize=letter)
    c.setFont("Helvetica", 12)
    c.rect(80, 720, 500, 70, stroke=1, fill=0) # Adjusted container dimensions
    c.setStrokeColorRGB(0, 0, 0)  # Border color (black)
    c.setLineWidth(1)  # Border width
    c.drawImage('UPLOAD_FOLDER/Logo.png', 90, 730, width=80, height=50)  
    c.setFont("Helvetica-Bold", 35)
    c.drawString(200, 743, "Parking Ticket Fine")  # Adjusted position
    c.setFont("Helvetica", 12)
    c.drawString(100, 680, f"Ticket Number: {ticket_number}")  # Adjusted position
    c.setFont("Helvetica-Bold", 12)
    c.drawString(100, 640, f"Car Registration Number: {registration_number}")
    c.setFont("Helvetica", 12)
    c.drawString(100, 660, f"Date of Offense: {payment_date}")  # Adjusted position

    violation_text = ("The vehicle mentioned above was found violating the parking laws.\n "
                      "The images below serve as evidence of the violation.\n "
                      "The car was parked in the designated no-parking area, \n"
                      "obstructing traffic flow and causing inconvenience to other drivers.")
    c.drawImage(car_picture1, 100, 400, width=200, height=150)  # Adjusted position
    c.drawImage(car_picture2, 350, 400, width=200, height=150)  # Adjusted position
    lines = violation_text.split('\n')
    y_position = 620  # Adjusted starting vertical position
    for line in lines:
        c.drawString(100, y_position, line)
        y_position -= 20  
    c.drawString(100, 380, f"Parking Location: {parking_location}")  # Adjusted position
    c.drawString(100, 360, f"Ticket Fine Price: {finePrice}")  # Adjusted position
    c.drawString(100, 340, f"Officer Number: {officerNumber}")  # Adjusted position
    c.save()

def store_ticket_info(ticket_number, registration_number, parking_location, payment_date, officer_number):
    conn = sqlite3.connect("parking_ticket.db")
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS ParkingTickets (
                        TicketNumber TEXT PRIMARY KEY,
                        RegistrationNumber TEXT,
                        ParkingLocation TEXT,
                        PaymentDate TEXT,
                        officer_number TEXT)''')

    cursor.execute('''INSERT INTO ParkingTickets (TicketNumber, RegistrationNumber, ParkingLocation, PaymentDate, officer_number)
                        VALUES (?, ?, ?, ?, ?)''', (ticket_number, registration_number, parking_location, payment_date, officer_number))

    conn.commit()
    conn.close()

def get_tickets(staffNumber):
    conn = sqlite3.connect("parking_ticket.db")
    cursor = conn.cursor()

    cursor.execute('''SELECT * FROM ParkingTickets
                   WHERE Officer_number=?''', (staffNumber,))
    rows = cursor.fetchall()

    conn.close()

    if rows:
        tickets = [{
            "ticket_number": row[0],
            "registration_number": row[1],
            "parking_location": row[2],
            "payment_date": row[3],
            "officer_number": row[4]
        } for row in rows]
        return jsonify(tickets)
    else:
        return jsonify([])