from flask import Flask, render_template, redirect, url_for, request, jsonify
from app import mysql  # Import MySQL connection from app.py


class owner:

    def update():
        if request.method == 'POST':
            ticketID = request.form['ticketID']
            newStatus = 'Paid'
            cur = mysql.connection.cursor()
            cur.execute(f'''UPDATE parkingChallan 
                            SET paymentStatus = %s
                            WHERE challanID = %s''', (newStatus, ticketID))
            mysql.connection.commit()
            return 'Ticket updated to Paid', 200

    def addTax():
        if request.method == 'POST':
            ticketID = request.form['ticketID']
            newStatus = 'Added To Tax'
            cur = mysql.connection.cursor()
            cur.execute('''UPDATE parkingChallan 
                        SET paymentStatus = %s
                        WHERE challanID = %s''', (newStatus, ticketID))
            mysql.connection.commit()
            return 'Ticket Added To Tax', 200
        
    def simulate_payment():
        violation_id = request.form['violation_id']
        return jsonify({'success': True, 'message': f'Payment successful for violation ID {violation_id}'})
    
    def login(): 
        usr = request.form['username']
        pas = request.form['password']
        if 'emp' in usr:
            return redirect(url_for('carOwner'))
        # Redirect to the landing page after successful login
        else:
            return redirect(url_for('carOwner'))
        
    def carOwner(): 
        username = request.form['username']
        cur = mysql.connection.cursor()
        cur.execute('''SELECT challanID, numberplate, date, violationDescription, amount, paymentStatus
                   FROM parkingChallan
                   WHERE IDnumber = %s''', (username,))
        fetchData = cur.fetchall()
        cur.close()
        return render_template('carOwner.html', data=fetchData)
