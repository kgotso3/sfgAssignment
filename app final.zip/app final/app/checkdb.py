import sqlite3

def create_tables():
    conn = sqlite3.connect("parking_ticket.db")
    cursor = conn.cursor()

    # Create ParkingTickets table
    cursor.execute('''CREATE TABLE IF NOT EXISTS ParkingTickets (
                        TicketNumber TEXT PRIMARY KEY,
                        RegistrationNumber TEXT,
                        ParkingLocation TEXT,
                        PaymentDate TEXT,
                        OfficerNumber TEXT)''')

    # Create TrafficOfficers table
    cursor.execute('''CREATE TABLE IF NOT EXISTS TrafficOfficers (
                        OfficerNumber TEXT PRIMARY KEY,
                        StaffCode TEXT,
                        Cellphone TEXT,
                        Email TEXT,
                        Ranking TEXT,
                        FirstName TEXT,
                        LastName TEXT)''')

    conn.commit()
    conn.close()


def store_officer_info(officer_number, staff_code, cellphone, email, ranking, first_name, last_name):
    conn = sqlite3.connect("parking_ticket.db")
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM TrafficOfficers WHERE OfficerNumber = ?''', (officer_number,))
    existing_officer = cursor.fetchone()
    if existing_officer:
        print(f"Officer with number {officer_number} already exists.")
    else:
        cursor.execute('''INSERT INTO TrafficOfficers (OfficerNumber, StaffCode, Cellphone, Email, Ranking, FirstName, LastName)
                        VALUES (?, ?, ?, ?, ?, ?, ?)''', (officer_number, staff_code, cellphone, email, ranking, first_name, last_name))

    conn.commit()
    conn.close()

# Example usage:
create_tables()

# Populating TrafficOfficers table
store_officer_info("OF123", "SC001", "0724023389", "johndoe@citytraffic.com", "Senior", "John", "Doe")
store_officer_info("OF124", "SC002", "0713027913", "janesmith@citytraffic.com", "Junior", "Jane", "Smith")
store_officer_info("OF125", "SC003", "0721003814", "davidbrown@citytraffic.com", "Senior", "David", "Brown")
store_officer_info("OF126", "SC004", "0734023389", "sarahjohnson@citytraffic.com", "Junior", "Sarah", "Johnson")
store_officer_info("OF127", "SC005", "0712378907", "michaelwilson@citytraffic.com", "Senior", "Michael", "Wilson")
def display_traffic_officers():
    conn = sqlite3.connect("parking_ticket.db")
    cursor = conn.cursor()

    cursor.execute('''SELECT * FROM TrafficOfficers''')
    rows = cursor.fetchall()
    print("Traffic Officers:")
    for row in rows:
        print(row)

    conn.close()
print()
display_traffic_officers()