from flask import Flask, render_template, redirect, url_for, request, jsonify,session
from services.trafficOfficer import generate_ticket_number, generate_payment_date, process_car_image, generate_pdf_ticket, store_ticket_info,get_tickets
from werkzeug.utils import secure_filename
from flask_mysqldb import MySQL
import os
import sqlite3
app = Flask(__name__)

users = {
    'user1': 'password1',
    'user2': 'password2'
}

app.config['MYSQL_HOST'] = 'sql11.freesqldatabase.com'
app.config['MYSQL_USER'] = 'sql11701280'
app.config['MYSQL_PASSWORD'] = 'pivICPYcpC'
app.config['MYSQL_DB'] = 'sql11701280'

mysql = MySQL(app)

global username
app.config['UPLOAD_FOLDER'] = 'C://Users//SphiwesihleSiyabonga//Desktop//SFG ASSignment//app//UPLOAD_FOLDER'
@app.route('/')
def index():
    return render_template('landingPage.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username1')
    #username = request.form['username1']
    #print(username)
    conn = sqlite3.connect("parking_ticket.db")
    cursor = conn.cursor()
    
    cursor.execute('''SELECT * FROM TrafficOfficers WHERE OfficerNumber = ?''', (username,))
    user = cursor.fetchone()
    #print(user)
    conn.close()
    
    if 'OF' in str(user):
        return redirect(url_for('carOwner'))
    else:
        return redirect(url_for('trafficOfficer',username=username))
        
    

@app.route('/trafficOfficer')
def trafficOfficer():
    #usr = session.get('usr')
    #print(username)
    #username = request.args.get('username')
    username='OF123'
    return render_template('trafficOfficer.html',username=username)
@app.route('/getTickets')
def getTickets():
    #username = request.args.get('username')
    #print(username)
    username='OF123'
    results=get_tickets(username)
    return results  

@app.route('/creatingTicket', methods=['POST', 'GET'])
def creatingTicket():
    if request.method == 'POST':
        car_picture1 = request.files['car_picture1']
        car_picture2 = request.files['car_picture2']
        registration_number = request.form['registration_number']
        parking_location = request.form['parking_location']
        officer_number = request.form['officer_number']
        car_found = request.form['carFound']

        fine_price = 0
        if car_found == '1':
            fine_price = 150
        elif car_found == '2':
            fine_price = 200
        ticket_number = generate_ticket_number()
        payment_date = generate_payment_date()
        car_picture1_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(car_picture1.filename))
        car_picture1.save(car_picture1_path)
        car_picture2_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(car_picture2.filename))
        car_picture2.save(car_picture2_path)
        generate_pdf_ticket(registration_number, parking_location, ticket_number, payment_date, car_picture1_path, car_picture2_path, officer_number, fine_price)
        store_ticket_info(ticket_number, registration_number, parking_location, payment_date, officer_number)
        return render_template('createTicket.html',ticket_created=True, ticket_number=ticket_number, registration_number=registration_number, parking_location=parking_location, officer_number=officer_number, car_found=car_found)

@app.route('/carOwner')
def carOwner():
    cur = mysql.connection.cursor()
    cur.execute(f'''select challanID,numberplate,date,violationDescription,amount,paymentStatus
                                        from parkingChallan 
                                        where IDnumber = '1234567890'; 
                                    ''')
    fetchData = cur.fetchall()
    cur.close()
    return render_template('carOwner.html', data = fetchData)

@app.route('/pay', methods=['POST'])
def simulate_payment():
    violation_id = request.form['violation_id']
    return jsonify({'success': True, 'message': f'Payment successful for violation ID {violation_id}'})

@app.route('/update', methods=['POST','GET'])
def update():
    if request.method == 'POST':
        ticketID = request.form['ticketID']
        newStatus = 'Paid'
        cur = mysql.connection.cursor()
        cur.execute(f'''UPDATE parkingChallan 
                        SET paymentStatus = %s
                        WHERE challanID = %s''', (newStatus, ticketID))
        mysql.connection.commit()
        return 'Ticket updated to Paid', 200
    
@app.route('/addTax', methods=['POST','GET'])
def addTax():
    if request.method == 'POST':
        ticketID = request.form['ticketID']
        newStatus = 'Added To Tax'
        cur = mysql.connection.cursor()
        cur.execute(f'''UPDATE parkingChallan 
                        SET paymentStatus = %s
                        WHERE challanID = %s''', (newStatus, ticketID))
        mysql.connection.commit()
        return 'Ticket Added To Tax', 200

if __name__ == '__main__':
    app.run(debug=True)




 