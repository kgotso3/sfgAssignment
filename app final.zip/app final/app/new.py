import sqlite3

def delete_table(table_name):
    conn = sqlite3.connect("parking_ticket.db")
    cursor = conn.cursor()

    cursor.execute('''DROP TABLE IF EXISTS {}'''.format(table_name))

    conn.commit()
    conn.close()

# Example usage:
delete_table("ParkingTickets")